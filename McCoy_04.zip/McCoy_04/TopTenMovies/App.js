import React, { useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  StatusBar,
} from "react-native";

const TOP_TEN_MOVIES = [
  {
    id: "1",
    title: "Liar Liar",
    posterImage:
      "https://m.media-amazon.com/images/M/MV5BMGQ4MTk5YjctNGE5NC00ODk4LWIzOWItNzNhODc0N2JmYzMzXkEyXkFqcGc@._V1_.jpg",
    rating: "9.0/10",
  },
  {
    id: "2",
    title: "Independence Day",
    posterImage:
      "https://m.media-amazon.com/images/M/MV5BOGMwN2UwZjEtYjFjMi00ZDA1LWJlYTQtMjA1MTYxMzIyNTdiXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg",
    rating: "8.5/10",
  },
  {
    id: "3",
    title: "Bruce Almighty",
    posterImage:
      "https://m.media-amazon.com/images/M/MV5BZWM2ZjA2OTctZmRhMy00ZDIzLTkwZGQtYTRlNmQwZWZmMDBlXkEyXkFqcGc@._V1_.jpg",
    rating: "8.5/10",
  },
  {
    id: "4",
    title: "Happy Gilmore",
    posterImage: "https://m.media-amazon.com/images/I/913i7HtDviL._AC_UF894,1000_QL80_.jpg",
    rating: "8.5/10",
  },
  {
    id: "5",
    title: "Night at the Museum",
    posterImage:
      "https://m.media-amazon.com/images/M/MV5BNGMyYjYyZDAtNzRiZC00ZjRkLTkwYjktODkxODQzNTFiMTVmXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg",
    rating: "8.0/10",
  },
  {
    id: "6",
    title: "Sweet Home Alabama",
    posterImage:
      "https://m.media-amazon.com/images/M/MV5BMjEwMjIwMDQ4OV5BMl5BanBnXkFtZTYwNzc3OTY3._V1_.jpg",
    rating: "7.5/10",
  },
  {
    id: "7",
    title: "Overboard (2018)",
    posterImage: "https://play-lh.googleusercontent.com/Pz7OBPZHdm98I1DKHt-AXR4Hzzdi-ZWwCTpGhdPPx2V12Eu2euKWIoI9FSc2bfz4rq9q",
    rating: "7.5/10",
  },
  {
    id: "8",
    title: "Grown Ups",
    posterImage:
      "https://m.media-amazon.com/images/M/MV5BMjA0ODYwNzU5Nl5BMl5BanBnXkFtZTcwNTI1MTgxMw@@._V1_.jpg",
    rating: "7.0/10",
  },
  {
    id: "9",
    title: "Mike and Dave Need Wedding Dates",
    posterImage:
      "https://m.media-amazon.com/images/M/MV5BZDU0YTQ4MjctM2RiMy00NjZlLThiZjgtYzM4ODNiMjRjMGM5XkEyXkFqcGc@._V1_.jpg",
    rating: "7.0/10",
  },
  {
    id: "10",
    title: "Madea's Destination Wedding",
    posterImage:
      "https://m.media-amazon.com/images/M/MV5BYzRkM2JmM2EtNTgzZi00MzdlLTkxM2ItNTlhNmQzZjM2NjA2XkEyXkFqcGc@._V1_QL75_UY281_CR19,0,190,281_.jpg",
    rating: "7.0/10",
  },
];

function MovieCard({ title, posterImage, rating }) {
  const [failed, setFailed] = useState(false);

  return (
    <View style={styles.card}>
      <Image
        source={
          failed
            ? require("./assets/fallback.png")
            : { uri: posterImage }
        }
        style={styles.poster}
        resizeMode="cover"
        onError={() => setFailed(true)}
      />

      <View style={styles.cardText}>
        <Text style={styles.movieTitle} numberOfLines={2}>
          {title}
        </Text>
        <Text style={styles.rating}>⭐ {rating}</Text>
      </View>
    </View>
  );
}

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      <Text style={styles.header}>My Top 10 Movies</Text>

      <FlatList
        data={TOP_TEN_MOVIES}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <MovieCard
            title={item.title}
            posterImage={item.posterImage}
            rating={item.rating}
          />
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0b1020" },
  header: {
    fontSize: 28,
    fontWeight: "800",
    color: "white",
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  card: {
    flexDirection: "row",
    backgroundColor: "#141a33",
    borderRadius: 14,
    padding: 12,
    marginTop: 12,
    alignItems: "center",
  },
  poster: {
    width: 70,
    height: 105,
    borderRadius: 10,
    backgroundColor: "#222",
  },
  cardText: { marginLeft: 12, flex: 1 },
  movieTitle: { color: "white", fontSize: 18, fontWeight: "700" },
  rating: { marginTop: 8, color: "#cdd6ff", fontSize: 14, fontWeight: "600" },
});